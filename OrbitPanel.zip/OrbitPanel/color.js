// color.js - Custom Color Palettes for OrbitPanel

// 1. Convert standard hex strings to PreSonus numeric values
function hexToPreSonusColor(hex) {
    // Strip '#' character if present
    if (hex.charAt(0) === '#') {
        hex = hex.substring(1);
    }
    
    // Parse individual color channels
    let r = parseInt(hex.substring(0, 2), 16);
    let g = parseInt(hex.substring(2, 4), 16);
    let b = parseInt(hex.substring(4, 6), 16);
    
    // PreSonus color engine format packed integer (Alpha channel set to 255/Opaque)
    return (255 << 24) | (r << 16) | (g << 8) | b;
}

// 2. Clear out old settings and load your custom grid arrangement
function loadOrbitPalettes(panelInstance) {
    // Combine your custom themes into a flat timeline grid array
    const masterPalette = [
        // --- PASTEL PALETTE ---
        "#FFB7B2", "#FFDAC1", "#E2F0CB", "#B5EAD7", "#C7CEEA",
        // --- NEON PALETTE ---
        "#FF0055", "#00FFCC", "#9900FF", "#FFFF00", "#FF6600",
        // --- STUDIO PALETTE ---
        "#3A3F47", "#4E545E", "#2A2D32", "#1F2124", "#5C6370"
    ];

    // Map your colors directly into the panel's active color array cells
    for (let i = 0; i < masterPalette.length; i++) {
        if (i < panelInstance.colorBox.length) {
            let numericColor = hexToPreSonusColor(masterPalette[i]);
            panelInstance.colorBox[i].value = numericColor;
        }
    }
}
