// functions.js - Main Execution Routines

function colorEvents(panelInstance, slotIndex) {
    // Connect directly to Studio One's active environment
    const hostApp = Host.Objects.getObjectByUrl("object://hostapp/DocumentManager/ActiveDocument/EditEnvironment/AddIns/studioone.orbitpanel.v1");
    const trackList = Host.Objects.getObjectByUrl("object://hostapp/DocumentManager/ActiveDocument/TrackList").mainTrackList;
    const mixerConsole = Host.Objects.getObjectByUrl("object://hostapp/DocumentManager/ActiveDocument/Environment/MixerConsole");
    
    if (!mixerConsole) return;
    const channelList = mixerConsole.getChannelList(1);
    
    panelInstance.firstClickGradSlot = slotIndex;
    
    // Grab hex color from target colorBox index 
    let hexString = panelInstance.colorBox[slotIndex].string.substring(1, 7); // Removes "#" symbol

    // Mode 1: Event-Only Coloring Toggle
    if (panelInstance.eventToggle && panelInstance.eventToggle.value === 1) {
        Host.GUI.Commands.interpretCommand(
            "Event", 
            "Color Events Hex Color (CT)", 
            false, 
            Host.Attributes(["Hex", hexString])
        );
        return;
    }

    // Mode 2: Track Isolation Filter Mode
    if (panelInstance.showByColor) {
        Host.GUI.Commands.interpretCommand(
            "Track", 
            "Show by Hex Color (CT)", 
            false, 
            Host.Attributes(["Hex", hexString, "Filter+", panelInstance.multipleFilters.value])
        );
        return;
    }

    // Mode 3: Apply color directly to selected tracks/channels
    if (channelList && channelList.numSelectedChannels > 0) {
        for (let i = 0; i < channelList.numSelectedChannels; i++) {
            let selectedChannel = channelList.getSelectedChannel(i);
            if (selectedChannel) {
                selectedChannel.color = panelInstance.colorBox[slotIndex].value;
            }
        }
    }
}
