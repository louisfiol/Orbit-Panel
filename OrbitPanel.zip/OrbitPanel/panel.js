
const kPackageID = "studioone.orbitpanel.v1";
const kUserCTDirectory = "local://$USERCONTENT/Color\x20Toolbar\x203/";

// File and configuration paths
const kUserOPSetupFile = kUserCTDirectory + "orbitpanel_setup.txt";
const kUserIconFile = kUserCTDirectory + "orbitpanel_icons.txt";
const kUserSettingsFile = kUserCTDirectory + "settings.xml";

const kResourceOPSetupFile =
  "package://" + kPackageID + "/resources/orbitpanel_setup.txt";
const kResourceSettingsFile =
  "package://" + kPackageID + "/resources/settings.xml";

// Slot range constants
const KEndColorSlot = 101;
const KNoMatchColorSlot = 96;
const KBusTypeColorSlot = 97;
const KFXTypeColorSlot = 98;
const KVCATypeColorSlot = 99;
const KAuxTypeColorSlot = 100;
const KInstTypeColorSlot = 101;

// Include dependent structural sub-scripts
include_file("functions.js");
include_file("match.js");
include_file("color.js");
include_file("filefunctions.js");

this["DEBUG"] = false;
let theOrbitPanel = null;

// Inherit from CCL Component framework
OrbitPanel.prototype = new CCL.Component();

function OrbitPanel(componentContext) {
  this.commandHandler = new _0x57fcc9(this);
  this.commandTargets = new Array();
  this.numStaticTargets = 0;

  this.initialize = function (paramStorage) {
    CCL.Component.prototype.initialize.call(this, paramStorage);

    // Core UI dynamic array declarations
    this.colorBox = [];
    this.slotName = [];
    this.slotKeyWords = [];
    this.iconName = [];
    this.iconCat = [];
    this.colorButton = [];
    this.slotNameButton = [];
    this.slotNumberButton = [];
    this.slotLabel = [];

    // Active runtime variables
    this.adjustColor = 0;
    this.incrementalColor = 0;
    this.slotIndex = 0;
    this.cursorIndex = 0;
    this.colorToolbarEdit = false;

    // UI String Parameters managed by the framework
    this.keyWords = this.paramList.addString("KeyWords");
    this.currentItem = this.paramList.addString("CurrentItem");
    this.currentEdit = this.paramList.addString("CurrentEdit");
    this.searchWord = this.paramList.addString("Search");
    this.searchWord.value = "";

    this.hexColorNumber = this.paramList.addString("HexColorNumber");
    this.hexColorNumber.value = "FFD829";

    // Fixed Integer Parameter to track display modes without prototype collision
    this.displayBarMode = this.paramList.addInteger(0, 1, "DisplayBarMode");
    this.displayBarMode.value = 0;

    // Tracking state flags
    this.showByColor = false;

    // Initialize Native Dropdown Filters
    this.filterMenu = this.paramList.addList("filterMenu");
    this.filterMenu.appendString("Show All");
    this.filterMenu.appendString("Show Selected");
    this.filterMenu.appendString("Show Soloed");
    this.filterMenu.appendString("Show Instruments");
    this.filterMenu.appendString("Show by Track Color");
    this.filterMenu.appendString("Reset Filter");

    // Menu allocations
    this.fileMenu = this.paramList.addMenu("FileMenu");
    this.presetMenu = this.paramList.addMenu("Presets");
    this.keywordColorBox = this.paramList.addColor("keywordColorBox");

    // Loop to dynamically bind and build the layout parameters
    for (let i = 0; i <= KEndColorSlot; i++) {
      this.colorBox[i] = this.paramList.addColor("ColorBox" + i);
      this.colorBox[i].value = 0;

      this.colorButton[i] = this.paramList.addParam("ColorButton" + i);
      this.slotNumberButton[i] = this.paramList.addParam(
        "SlotNumberButton" + i,
      );
      this.slotNameButton[i] = this.paramList.addParam("SlotNameButton" + i);
    }

    // Loop through all color slots to attach change notification bindings
    for (let i = 0; i <= KEndColorSlot; i++) {
      this.colorButton[i].onValueChanged = (function (
        panelInstance,
        clickedIndex,
      ) {
        return function () {
          panelInstance.handleColorButtonClick(clickedIndex);
        };
      })(this, i);

      this.slotNameButton[i].onValueChanged = (function (
        panelInstance,
        clickedIndex,
      ) {
        return function () {
          panelInstance.handleSlotNameClick(clickedIndex);
        };
      })(this, i);
    }
  }; // End of initialize method

  // -------------------------------------------------------------
  // INTERACTION LOGIC METHODS
  // -------------------------------------------------------------

  // Executes when a color block cell is clicked on the palette grid
  this.handleColorButtonClick = function (slotIndex) {
    if (this["DEBUG"]) {
      console.log("OrbitPanel: Color Button Clicked at Slot ID: " + slotIndex);
    }

    this.slotIndex = slotIndex;

    if (typeof colorEvents === "function") {
      colorEvents(this, slotIndex);
    }
  };

  // Executes when a label/track name field inside a slot is triggered
  this.handleSlotNameClick = function (slotIndex) {
    this.slotIndex = slotIndex;

    if (typeof matchTracksByName === "function") {
      matchTracksByName(this, slotIndex);
    }
  };
} // End of OrbitPanel Class
